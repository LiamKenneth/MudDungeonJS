# MudDungeonJS
[![Build Status](https://travis-ci.org/LiamKenneth/MudDungeonJS.svg)](https://travis-ci.org/LiamKenneth/MudDungeonJS) [![codecov.io](https://codecov.io/github/LiamKenneth/MudDungeonJS/coverage.svg?branch=master)](https://codecov.io/github/LiamKenneth/MudDungeonJS?branch=master)

Using this project to learn NodeJS & JavasScript Testing!

Will be a mud engine using telnet and Web sockets for web, built with NodeJs

#How to run it
Enter npm install

Enter gulp to start the project & go to 127.0.0.1:23 in a mud client

Enter gulp test to run the unit tests
